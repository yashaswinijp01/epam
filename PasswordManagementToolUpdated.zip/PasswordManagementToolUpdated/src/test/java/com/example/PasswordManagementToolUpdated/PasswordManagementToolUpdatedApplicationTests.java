package com.example.PasswordManagementToolUpdated;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasswordManagementToolUpdatedApplicationTests {

	@Test
	void contextLoads() {
	}

}
