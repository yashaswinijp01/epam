package com.example.PasswordManagementToolUpdated.dao;

import com.example.PasswordManagementToolUpdated.bean.UserBean;
import com.example.PasswordManagementToolUpdated.entity.User;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class UserDaoWrapper {
    @Autowired
    UserDao userDao;
    @Autowired
    ModelMapper modelMapper;
    public int save(UserBean userBean) {
        User user = modelMapper.map(userBean,User.class);
        User user1 = userDao.save(user);
        return user1.getId();

    }


    public List<UserBean> findAllUser() {
       List<User> users =  (List<User>) userDao.findAll();
       List<UserBean> userBean = new ArrayList<>();

       for(User user:users){
           userBean.add(modelMapper.map(user,UserBean.class));
       }
      return userBean;
    }
}
