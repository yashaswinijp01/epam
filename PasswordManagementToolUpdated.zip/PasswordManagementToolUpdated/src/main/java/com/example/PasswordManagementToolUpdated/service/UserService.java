package com.example.PasswordManagementToolUpdated.service;

import com.example.PasswordManagementToolUpdated.bean.UserBean;
import com.example.PasswordManagementToolUpdated.entity.User;
import org.springframework.stereotype.Service;

import java.util.List;

public interface UserService {
    int adduser(UserBean userBean);
    List<UserBean> findAllUser();
    
}
