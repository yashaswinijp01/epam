package com.example.PasswordManagementToolUpdated.bean;

import lombok.*;
import org.springframework.stereotype.Component;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Component
public class UserBean {

    private int id;

    private String firstname;
    private String lastname;
    private String username;
    private String password;
}
