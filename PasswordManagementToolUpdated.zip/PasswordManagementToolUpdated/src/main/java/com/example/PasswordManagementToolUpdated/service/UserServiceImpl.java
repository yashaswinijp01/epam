package com.example.PasswordManagementToolUpdated.service;

import com.example.PasswordManagementToolUpdated.bean.UserBean;
import com.example.PasswordManagementToolUpdated.dao.UserDao;
import com.example.PasswordManagementToolUpdated.dao.UserDaoWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{
@Autowired
UserDaoWrapper userDaoWrapper;
    @Override
    public int adduser(UserBean userBean) {
        int userid = userDaoWrapper.save(userBean);
        return userid;
    }

    @Override
    public List<UserBean> findAllUser() {
        List<UserBean> userBean = userDaoWrapper.findAllUser();
        return userBean;
    }
}
