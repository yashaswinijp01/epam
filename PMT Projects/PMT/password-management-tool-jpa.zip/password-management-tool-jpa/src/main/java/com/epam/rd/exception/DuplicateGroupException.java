package com.epam.rd.exception;

public class DuplicateGroupException extends Exception {
    public DuplicateGroupException(String message) {
        super(message);
    }
}
