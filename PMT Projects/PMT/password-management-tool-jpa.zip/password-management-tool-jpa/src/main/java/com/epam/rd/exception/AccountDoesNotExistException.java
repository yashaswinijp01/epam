package com.epam.rd.exception;

public class AccountDoesNotExistException extends Exception {
    public AccountDoesNotExistException(String message) {
    }
}
