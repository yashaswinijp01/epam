package com.epam.rd.dao.interfaces;

import com.epam.rd.dto.GroupDto;
import com.epam.rd.dto.UserDto;
import com.epam.rd.exception.DuplicateGroupException;
import com.epam.rd.exception.GroupDoesNotExistException;
import java.util.List;

public interface GroupDaoWrapper {
    void saveGroup(GroupDto group , UserDto userDto) throws DuplicateGroupException;
    List<GroupDto> getAllGroups(UserDto userDto) ;
    GroupDto getGroupById(int groupId , UserDto userDto) throws GroupDoesNotExistException;
    void updateGroupsById(int groupId , GroupDto groupDto, UserDto userDto) throws GroupDoesNotExistException, DuplicateGroupException;

    void deleteGroupById(int i, UserDto userDto) throws GroupDoesNotExistException;
}
