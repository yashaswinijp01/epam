package com.epam.rd.dao.interfaces;

import com.epam.rd.dto.AccountDto;
import com.epam.rd.dto.UserDto;
import com.epam.rd.exception.AccountDoesNotExistException;
import com.epam.rd.exception.DuplicateAccountException;
import java.util.List;

public interface AccountDaoWrapper {
    void saveAccount(AccountDto accountDto, UserDto userDto) throws DuplicateAccountException;
    AccountDto getAccountById(int accountId , UserDto userDto) throws AccountDoesNotExistException;
    List<AccountDto> getAllAccounts(UserDto userDto);
    void removeAccountById(int accountId , UserDto userDto) throws AccountDoesNotExistException;
    void updateAccountById(AccountDto account, int accountId , UserDto userDto) throws AccountDoesNotExistException, DuplicateAccountException;

    List<AccountDto> getUnAssignedAccounts(UserDto userDto);
}
