package com.epam.rd.service.interfaces;

import com.epam.rd.dto.AccountDto;
import com.epam.rd.exception.AccountDoesNotExistException;
import com.epam.rd.exception.DuplicateAccountException;
import java.util.List;

public interface AccountService {
    void saveAccount(AccountDto accountDto) throws DuplicateAccountException;
    AccountDto getAccountById(int accountId) throws AccountDoesNotExistException;
    List<AccountDto> getAllAccount();
    void updateAccountById(AccountDto accountDto, int accountId) throws AccountDoesNotExistException, DuplicateAccountException;
    void removeAccountById(int accountId) throws AccountDoesNotExistException;

    List<AccountDto> getUnassignedAccounts();
}
