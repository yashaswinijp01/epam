package com.epam.rd.service.interfaces;

import com.epam.rd.dto.UserDto;
import com.epam.rd.exception.DuplicateUserException;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
    void saveUser(UserDto userDto) throws DuplicateUserException;
    UserDto getUserByUserName(String userName);
}
