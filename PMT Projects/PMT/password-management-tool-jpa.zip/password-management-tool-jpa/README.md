# Password Management Tool 

## Vision:
>Build secured password management tool which supports various interfaces like Web, Smart Devices, browser plugins, Application Plugins. The application should be scalable, maintainable.

## Introduction:
>We have to remember many passwords for our day to day activities. But it is very tedious job as the secured application list is growing day by day. So one can use Password Management Tool to maintain the passwords for each application and user can remember only one master password. As PMT stores data in PC's Memory, it should have strong encryption before storing the user's personal data to the hard drive or any where.

## Operations:
>* ***Create Password for an account:*** Add or create password for an account for a website or application with application user/URL/Password for specific group or default group. with high security.
>* ***Read Password:*** User should be able to view password for specific account from a group
>* ***List Password account and groups:*** Display all accounts by group
>*   ***Delete Password account:*** Delete password account.
>*   ***Modify/Update password account:*** Modify or update the password/account details
>*   ***Modify Group details:*** Update group name
>*   ***Delete Group:*** delete account groups

## Validations:

>1. Password Length and Characters should be defined by user and while creating account password we need to validate
>1. A Password account should belong to one group only
>1. The password account name should be unique with in the group
>1. User should be able to create a unique group and group name should have only alphabet chars
>1. URL for account should have proper format
>1. Password account name should have only Alphabets


