package com.epam.rd.controller;

import com.epam.rd.config.JwtTokenUtil;
import com.epam.rd.dto.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin("http://localhost:4200/")
@RestController
public class AuthController {
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @PostMapping(value = "login" , produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String , String> login(@RequestBody UserDto userDto){
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(userDto.getUserName(), userDto.getPassword()));
        String token = jwtTokenUtil.generateToken(authentication.getName());
        Map <String , String > map = new HashMap<>();
        map.put("jwt",token);
        return map;
    }

}
