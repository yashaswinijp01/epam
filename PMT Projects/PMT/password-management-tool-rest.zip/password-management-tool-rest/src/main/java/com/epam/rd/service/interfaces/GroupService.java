package com.epam.rd.service.interfaces;
import com.epam.rd.dto.GroupDto;
import com.epam.rd.exception.DuplicateGroupException;
import com.epam.rd.exception.GroupDoesNotExistException;
import java.util.List;

public interface GroupService {
    void saveGroup(GroupDto groupBean) throws DuplicateGroupException;
    List<GroupDto> getAllGroups() ;
    GroupDto getGroupById(int groupId) throws GroupDoesNotExistException;
    void updateGroupById(int groupId , GroupDto groupBean) throws DuplicateGroupException, GroupDoesNotExistException;
    void deleteGroupById(int groupId) throws GroupDoesNotExistException;
}
