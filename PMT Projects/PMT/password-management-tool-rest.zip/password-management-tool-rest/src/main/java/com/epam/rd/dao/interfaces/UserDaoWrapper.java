package com.epam.rd.dao.interfaces;

import com.epam.rd.dto.UserDto;
import com.epam.rd.exception.DuplicateUserException;

public interface UserDaoWrapper {
    void saveUser(UserDto userBean) throws DuplicateUserException;
    UserDto getUserByUserName(String userName) ;
}
