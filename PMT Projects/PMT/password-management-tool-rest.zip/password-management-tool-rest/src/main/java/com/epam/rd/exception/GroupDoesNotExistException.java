package com.epam.rd.exception;

public class GroupDoesNotExistException extends Exception {
    public GroupDoesNotExistException(String message) {
        super(message);
    }
}
