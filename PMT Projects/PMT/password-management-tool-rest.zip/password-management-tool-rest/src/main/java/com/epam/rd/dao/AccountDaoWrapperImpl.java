package com.epam.rd.dao;

import com.epam.rd.dto.AccountDto;
import com.epam.rd.dto.UserDto;
import com.epam.rd.dao.interfaces.AccountDao;
import com.epam.rd.dao.interfaces.AccountDaoWrapper;
import com.epam.rd.exception.AccountDoesNotExistException;
import com.epam.rd.exception.DuplicateAccountException;
import com.epam.rd.model.Account;
import com.epam.rd.model.User;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository("accountDaoWrapper")
public class AccountDaoWrapperImpl implements AccountDaoWrapper {
    @Autowired
    private AccountDao accountDao;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public void saveAccount(AccountDto accountDto , UserDto userDto) throws DuplicateAccountException {
        Account account = modelMapper.map(accountDto , Account.class);
        User user = getUserFromBean(userDto);
        checkForDuplicate(account.getAccountName(), user);
        accountDao.save(account);
    }

    private User getUserFromBean(UserDto userDto) {
        return modelMapper.map(userDto, User.class);
    }

    private void checkForDuplicate(String accountName, User user) throws DuplicateAccountException {
        if(accountDao.countByAccountNameAndUser(accountName, user)>0){
            throw new DuplicateAccountException("Account Already Exist");
        }
    }

    @Override
    public AccountDto getAccountById(int accountId, UserDto userDto) throws AccountDoesNotExistException {
        User user = getUserFromBean(userDto);
        List<Account> accounts = accountDao.findByAccountIdAndUser(accountId , user);
        if(accounts.isEmpty()){
            throw new AccountDoesNotExistException("Account Does not Exist with Account Id "+accountId);
        }
        return modelMapper.map(accounts.get(0) , AccountDto.class);
    }

    @Override
    public List<AccountDto> getAllAccounts(UserDto userDto) {
        User user = getUserFromBean(userDto);
        List<Account> accounts = accountDao.findByUser(user);
        List<AccountDto> accountBeans = new ArrayList<>();
        accounts.forEach(account -> accountBeans.add(modelMapper.map(account , AccountDto.class)));
        return accountBeans;
    }

    @Override
    public List<AccountDto> getUnAssignedAccounts(UserDto userDto) {
        User user = getUserFromBean(userDto);
        List<Account> accounts = accountDao.findByUserAndGroup(user , null);
        List<AccountDto> accountBeans = new ArrayList<>();
        accounts.forEach(account -> accountBeans.add(modelMapper.map(account , AccountDto.class)));
        return accountBeans;
    }

    @Override
    public void removeAccountById(int accountId, UserDto userBean) throws AccountDoesNotExistException {
        AccountDto accountBean = getAccountById(accountId , userBean);
        Account account = modelMapper.map(accountBean , Account.class);
        accountDao.delete(account);
    }

    @Override
    public void updateAccountById(AccountDto accountDto, int accountId, UserDto userDto) throws AccountDoesNotExistException, DuplicateAccountException {
        AccountDto accountDto1 = getAccountById(accountId , userDto);
        User user = modelMapper.map(userDto , User.class);
        if(!accountDto1.getAccountName().equals(accountDto.getAccountName())){
            checkForDuplicate(accountDto.getAccountName() , user);
        }
        copyProperties(accountDto, accountDto1);
        Account account1 = modelMapper.map(accountDto1 , Account.class);
        accountDao.save(account1);
    }

    private void copyProperties(AccountDto accountDto,AccountDto accountDto1) {
        accountDto1.setAccountName(accountDto.getAccountName());
        accountDto1.setUserName(accountDto.getUserName());
        accountDto1.setPassword(accountDto.getPassword());
        accountDto1.setUrl(accountDto.getUrl());
        accountDto1.setGroup(accountDto.getGroup());
        accountDto1.setLastModifiedAt(accountDto.getLastModifiedAt());
    }

}
