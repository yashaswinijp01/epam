package com.epam.ui;

import java.util.Optional;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.epam.config.SpringDataJpaConfig;
import com.epam.dao.StudentDao;
import com.epam.entity.Student;

public class UITester {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(SpringDataJpaConfig.class);

		StudentDao dao = (StudentDao) context.getBean("studentDao");

		System.out.println("Enter the student data");
		Scanner scan = new Scanner(System.in);
		String name = scan.next();
		String addreess = scan.next();
		Student s = new Student(name, addreess);

		Student insertedStudent = dao.save(s);
		
		System.out.println(insertedStudent);
		
		// update student address 
		
		Optional<Student> udpatedStudent  = dao.findById(1);
		
		Student std = udpatedStudent.get();
		String updatedaddreess = scan.next();
		std.setAddress(updatedaddreess);
		
		dao.save(std);
		
		
		System.out.println(dao.findAll());
		
		
	}

}
