package com.epam.config;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan("com.epam")
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "com.epam.dao", transactionManagerRef = "transactionManager")
public class SpringDataJpaConfig {

	@Bean
	public DataSource dataSource() {
		// DriverManagerDataSource();

//		DriverManagerDataSource dataSource = new DriverManagerDataSource();
//		dataSource.setUrl();
//		dataSource.setUsername(null);
//		dataSource.setPassword(null);
//		dataSource.setDriverClassName(null);

		return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.H2)
				// .addScript("classpath:jpa/schema.sql")
				.build();
	}

	@Bean
	public HibernateJpaVendorAdapter getHibnerateProvider() {
		HibernateJpaVendorAdapter provider = new HibernateJpaVendorAdapter();
		provider.setShowSql(true);
		provider.setGenerateDdl(true); // update,validate,create,create-drop
		provider.setDatabasePlatform("org.hibernate.dialect.H2Dialect");
		return provider;
	}

	@Bean(name="entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean getEntityManagerFactoryBean() {
		LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
		entityManagerFactoryBean.setDataSource(dataSource());
		entityManagerFactoryBean.setJpaVendorAdapter(getHibnerateProvider());
		entityManagerFactoryBean.setPackagesToScan("com.epam");
		return entityManagerFactoryBean;
	}

	@Bean(name="transactionManager")
	public JpaTransactionManager getTransactionManager(EntityManagerFactory entityManagerFactory) {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactory);
		return transactionManager;
	}

}
