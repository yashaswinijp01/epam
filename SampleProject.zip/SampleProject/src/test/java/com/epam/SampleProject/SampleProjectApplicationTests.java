package com.epam.SampleProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
