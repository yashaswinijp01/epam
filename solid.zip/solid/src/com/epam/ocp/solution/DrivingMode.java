package com.epam.ocp.solution;

public interface DrivingMode {

    int getPower();
    int getSuspensionHeight();
}
