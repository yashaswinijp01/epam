/**
 * 
 */
package com.epam.ocp.solution;

/**
 * @author Venu_Kandagatla
 *
 */
public class HillDrivingMode implements DrivingMode {

    @Override
    public int getPower() {
        // TODO Auto-generated method stub
        return 600;
    }

    @Override
    public int getSuspensionHeight() {
        // TODO Auto-generated method stub
        return 25;
    }

}
