/**
 * 
 */
package com.epam.ocp.solution;

/**
 * @author Venu_Kandagatla
 *
 */
public class VehicleDriver {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        EventHandler eh = new EventHandler(vehicle);
        
        DrivingMode drivingMode = new HillDrivingMode();
        eh.changeDrivingMode(drivingMode);
    }

}
