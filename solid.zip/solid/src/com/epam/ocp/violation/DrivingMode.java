package com.epam.ocp.violation;

public enum DrivingMode {
    SPORT, COMFORT, ECONOMY
}
