/**
 * 
 */
package com.epam.srp.solution;

/**
 * @author Venu_Kandagatla
 *
 */
public class VehicleFuelApp {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle(35);
        FuelPump pump = new FuelPump();
        pump.reFuel(vehicle);
        vehicle.accelerate();
        pump.reFuel(vehicle);
    }

}
