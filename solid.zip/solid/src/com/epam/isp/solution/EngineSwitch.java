package com.epam.isp.solution;

public interface EngineSwitch {

    void startEngine();

    void shutDownEngine();

}

