package com.epam.isp.solution;

public interface CameraSwitch {

    void turnCameraOn();

    void turnCameraOff();
}

