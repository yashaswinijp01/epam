package com.epam.isp.solution;

public interface RadioSwitch {

    void turnRadioOn();

    void turnRadioOff();
}

