package com.epam.dip.solution;

public interface Vehicle {

    void accelerate();

}