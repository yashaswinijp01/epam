/**
 * 
 */
package com.epam.dip.solution;


/**
 * @author Venu_Kandagatla
 *
 */
public class CarRacingSport {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Driver venu = new Driver(new RacingCar(100));
        venu.increaseSpeed();
        

    }

}
