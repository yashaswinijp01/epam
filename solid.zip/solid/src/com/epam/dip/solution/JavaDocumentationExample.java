/**
 * This file contains about naming conventions and java doc details.
 */
package com.epam.dip.solution;

import java.io.Console;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;

/**
 * @author Venu_Kandagatla
 *
 */
public class JavaDocumentationExample {
    /**
     * This is the user name for the applicant.
     */
    private String userName;

    /**
     * This method is used to calculate how much percentage of loan provided for
     * an applicant.
     * 
     * @param cibilScore
     *            is an int parameter ranges from 0 to 900
     * @param salaryRange
     *            is an int parameter ranges from 0 to 10
     * @return returns -1 for not eligibility, 1 to 100 for salary range.
     */
    public String calculatePossibleLoanAmount(int cibilScore, int salaryRange) {
        String name = "Venu Kandagatla";
        String newName = name.concat(" Mr").substring(5);
        return newName;
    }

    /**
     * @param args
     * @throws FileNotFoundException 
     */
    public static void main(String[] args) throws FileNotFoundException {
        JavaDocumentationExample jde = new JavaDocumentationExample();
        String s = jde.calculatePossibleLoanAmount(0, 0).substring(0, 11);
        Console console = System.console();
//        InputStream inputStream = new FileInputStream(new File("d:\\input.txt"));
//        System.setIn(inputStream);
        OutputStream output = new FileOutputStream(new File("d:\\output.txt"));
        PrintStream print = new PrintStream(output);
        OutputStream errorOut = new FileOutputStream(new File("d:\\errput.txt"));
        PrintStream errorOutPrint = new PrintStream(errorOut);
        System.setErr(errorOutPrint);
        System.err.println("I got some error....");
        System.setOut(print);
        if(s.length() > 10) {
            System.out.println(10);
        }else {
            System.out.println(100);
        }
        System.out.println(s.length() > 10 ? 10 : 100);
    }

}
