/**
 * 
 */
package com.epam.rd.weektwo;

import java.io.Console;

/**
 * @author Venu_Kandagatla
 *
 */
public class DisplayFirstLastName {

    public static void displayName(String firstName, String lastName,
            String displayFormat) {
        switch (displayFormat) {
        case "LF":
            System.out.printf("%s %s",lastName, firstName);
            break;
        case "FL":
        default:
            System.out.printf("%s %s",firstName, lastName);
            break;
        }
    }

    public static void main(String[] args) {
        // Get the console reference
        Console console = System.console();

        // Ask for first name
        System.out.println("Enter first name");
        String firstName = console.readLine();

        // Ask for last name
        System.out.println("Enter last name");
        String lastName = console.readLine();

        // Ask for format of the name
        System.out.println("Enter Display format (FL/LF)");
        String displayFormat = console.readLine();

        displayName(firstName, lastName, displayFormat);

    }

}
