package com.epam;

public class Example {

}
