package com.epam.lsp.solution;


public class Plane extends Vehicle {

    // A plane can reverse engine gear while moving forward, no problem here
}
