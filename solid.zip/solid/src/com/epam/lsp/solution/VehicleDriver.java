/**
 * 
 */
package com.epam.lsp.solution;

/**
 * @author Venu_Kandagatla
 *
 */
public class VehicleDriver {

    /**
     * 
     */
    public VehicleDriver() {
        
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        Vehicle v = new Plane();
        v.changeGear(Gear.D);
        v.changeGear(Gear.R);
        v = new Car();
        v.changeGear(Gear.D );
        v.changeGear(Gear.R );
    }

}
