package com.epam.lsp.solution;

public enum Gear {
    P, // Parking
    R, // Reverse
    N, // Neutral
    D // Drive
}
