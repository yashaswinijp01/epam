package com.epam.lsp.violation;

public class Car extends Vehicle {

    @Override
    public void changeGear(Gear gear) {
        if (Gear.R.equals(gear) && getGear().equals(Gear.D)) {
            System.out.println("Run time exception...");
            throw new RuntimeException("Can't change to REVERSE gear when "
                    + getGear().toString() + " gear is engaged!");
            
        }
    }
}
