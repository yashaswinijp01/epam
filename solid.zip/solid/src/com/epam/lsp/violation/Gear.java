package com.epam.lsp.violation;

public enum Gear {
    P, // Parking
    R, // Reverse
    N, // Neutral
    D // Drive
}
