package com.epam.lsp.violation;

public class Plane extends Vehicle {

    // A plane can reverse engine gear while moving forward, no problem here
}
