# springboot-crud-restful-webservices
## YouYube Video
Spring Boot, MySQL, JPA, Hibernate Restful CRUD API Tutorial at https://youtu.be/QXFgzomuDOg

## Blog post
https://www.javaguides.net/2020/04/spring-boot-mysql-jpa-hibernate-restful-crud-api-tutorial.html
