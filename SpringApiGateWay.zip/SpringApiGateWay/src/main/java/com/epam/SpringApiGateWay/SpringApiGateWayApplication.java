package com.epam.SpringApiGateWay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringApiGateWayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringApiGateWayApplication.class, args);
	}

}
