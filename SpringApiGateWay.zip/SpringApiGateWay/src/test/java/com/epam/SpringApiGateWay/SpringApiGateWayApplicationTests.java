package com.epam.SpringApiGateWay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApiGateWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
