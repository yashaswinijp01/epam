# library-management-service

Library Management Service using microservices

We will have three microservices:
    
        Book
        User
        Library

## Books

Books will contain methods books service

## User

User will contain methods for user service

## Library

Will contain library functionalities along with communication with users and books