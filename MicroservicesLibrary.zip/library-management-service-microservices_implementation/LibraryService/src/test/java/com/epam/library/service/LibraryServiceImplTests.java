package com.epam.library.service;

import com.epam.library.dao.LibraryDao;
import com.epam.library.dao.LibraryDaoWrapper;
import com.epam.library.entity.Library;
import com.epam.library.exception.BookAlreadyAllottedException;
import com.epam.library.exception.MaximumBookAllottedToUserException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(MockitoExtension.class)
class LibraryServiceImplTests {
    @InjectMocks
    LibraryServiceImpl libraryService;

    @Mock
    LibraryDaoWrapper libraryDaoWrapper;

    @Mock
    LibraryDao libraryDao;

    @Test
    void save() {
        Library library = new Library(1,"user",1);
        Mockito.when(libraryDaoWrapper.save(Mockito.any())).thenReturn(library);
        Mockito.when(libraryDao.countByUsername(Mockito.anyString())).thenReturn(1);
        Mockito.when(libraryDao.findByUsernameAndBookId(Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
        Library library1 = libraryService.save(new Library(1, "user", 1));
        Assertions.assertEquals(library.getBookId(), library1.getBookId());
        Assertions.assertEquals(library.getUsername(), library1.getUsername());
    }

    @Test
    void saveWhenExceptionForMaxBooks() {
        Library library = new Library(1,"user",1);
        Mockito.when(libraryDao.countByUsername(Mockito.anyString())).thenReturn(4);
        Mockito.when(libraryDao.findByUsernameAndBookId(Mockito.anyString(), Mockito.anyInt())).thenReturn(null);
        MaximumBookAllottedToUserException maximumBookException = assertThrows(MaximumBookAllottedToUserException.class, () ->
                libraryService.save(new Library(1, "user", 1)));
        assertTrue(maximumBookException.getMessage().contains("Book slots filled for user"));
    }

    @Test
    void saveWhenExceptionForAllottedBook() {
        Library library = new Library(1,"user",1);
        Mockito.when(libraryDao.countByUsername(Mockito.anyString())).thenReturn(1);
        Mockito.when(libraryDao.findByUsernameAndBookId(Mockito.anyString(), Mockito.anyInt())).thenReturn(new Library());
        BookAlreadyAllottedException exception = assertThrows(BookAlreadyAllottedException.class, () ->
                libraryService.save(new Library(1, "user", 1)));
        assertTrue(exception.getMessage().contains("Book already allotted to user"));
    }

    @Test
    void deleteByUsernameAndBookId() {
        Library library = new Library(1,"user",1);
        Mockito.when(libraryDaoWrapper.deleteByUsernameAndBookId(Mockito.anyString(), Mockito.anyInt())).thenReturn(library);
        Library library1 = libraryService.deleteByUsernameAndBookId("", 1);
        Assertions.assertEquals(library.getBookId(), library1.getBookId());
        Assertions.assertEquals(library.getUsername(), library1.getUsername());
    }
}