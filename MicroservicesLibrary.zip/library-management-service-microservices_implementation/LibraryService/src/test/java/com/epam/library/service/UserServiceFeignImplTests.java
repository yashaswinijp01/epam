package com.epam.library.service;

import com.epam.library.bean.BookBean;
import com.epam.library.bean.UserBean;
import com.epam.library.bean.UsersBookBean;
import com.epam.library.clients.UserClient;
import com.epam.library.dao.LibraryDaoWrapper;
import com.epam.library.entity.Library;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class UserServiceFeignImplTests {
    @InjectMocks
    UserServiceFeignImpl userServiceFeign;

    @Mock
    BookServiceFeignImpl bookServiceFeign;

    @Mock
    LibraryDaoWrapper libraryDaoWrapper;

    @Mock
    UserClient userClient;

    @Test
    void getUsers() {
        UserBean user = new UserBean(1, "user", "user@test.com", "user");
        List<UserBean> users = List.of(user);
        Mockito.when(userClient.getAllUsers()).thenReturn(users);
        List<UserBean> userBeans = userServiceFeign.getUsers();
        assertEquals(1, userBeans.size());
        Mockito.verify(userClient, Mockito.times(1)).getAllUsers();
    }

    @Test
    void getUserByUsername() {
        UserBean user = new UserBean(1, "user", "user@test.com", "user");
        BookBean bean = new BookBean(1, "name", "pub", "auth");
        Library library = new Library(1, "user", 1);
        List<Library> libraryList = List.of(library);
        Mockito.when(libraryDaoWrapper.findByUsername(Mockito.anyString())).thenReturn(libraryList);
        Mockito.when(bookServiceFeign.getBookById(Mockito.anyInt())).thenReturn(bean);
        Mockito.when(userClient.getUserByUsername(Mockito.anyString())).thenReturn(user);
        UsersBookBean response = userServiceFeign.getUserByUsername("");
        assertEquals(user.getUsername(), response.getUserBean().getUsername());

    }

    @Test
    void addUser() {
        UserBean user = new UserBean(1, "user", "user@test.com", "user");
        Mockito.when(userClient.addUser(Mockito.any())).thenReturn(user);
        UserBean userBean = userServiceFeign.addUser(new UserBean());
        assertEquals(user.getEmail(), userBean.getEmail());
        assertEquals(user.getUsername(), userBean.getUsername());
        assertEquals(user.getName(), userBean.getName());
        Mockito.verify(userClient, Mockito.times(1)).addUser(Mockito.any());
    }

    @Test
    void deleteUserByUsername() {
        UserBean user = new UserBean(1, "user", "user@test.com", "user");
        Mockito.when(userClient.deleteUser(Mockito.anyString())).thenReturn(user);
        UserBean userBean = userServiceFeign.deleteUserByUsername("");
        assertEquals(user.getEmail(), userBean.getEmail());
        assertEquals(user.getUsername(), userBean.getUsername());
        assertEquals(user.getName(), userBean.getName());
        Mockito.verify(userClient, Mockito.times(1)).deleteUser(Mockito.anyString());
    }

    @Test
    void updateUserByUsername() {
        UserBean user = new UserBean(1, "user", "user@test.com", "user");
        Mockito.when(userClient.updateUser(Mockito.anyString(), Mockito.any())).thenReturn(user);
        UserBean userBean = userServiceFeign.updateUserByUsername(new UserBean(), "");
        assertEquals(user.getEmail(), userBean.getEmail());
        assertEquals(user.getUsername(), userBean.getUsername());
        assertEquals(user.getName(), userBean.getName());
        Mockito.verify(userClient, Mockito.times(1)).updateUser(Mockito.anyString(), Mockito.any());
    }

    @Test
    void issueBookToUser() {
        UserBean user = new UserBean(1, "user", "user@test.com", "user");
        Mockito.when(userClient.getUserByUsername(Mockito.anyString())).thenReturn(user);
        UserBean userBean = userServiceFeign.issueBookToUser("", 1);
        assertEquals(user.getEmail(), userBean.getEmail());
        assertEquals(user.getUsername(), userBean.getUsername());
        assertEquals(user.getName(), userBean.getName());
        Mockito.verify(userClient, Mockito.times(1)).getUserByUsername(Mockito.anyString());
    }
}