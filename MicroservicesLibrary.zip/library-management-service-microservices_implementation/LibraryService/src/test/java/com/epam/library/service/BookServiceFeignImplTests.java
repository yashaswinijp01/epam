package com.epam.library.service;

import com.epam.library.bean.BookBean;
import com.epam.library.clients.BookClient;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class BookServiceFeignImplTests {
    @InjectMocks
    BookServiceFeignImpl bookServiceFeign;

    @Mock
    BookClient bookClient;

    @Test
    void getAllBooksFromLibrary() {
        BookBean book = new BookBean(1, "Book1", "Pub1", "Aut1");
        List<BookBean> books = List.of(book);
        Mockito.when(bookClient.getBooks()).thenReturn(books);
        List<BookBean> beanList = bookServiceFeign.getAllBooksFromLibrary();
        assertEquals(1, beanList.size());
        Mockito.verify(bookClient, Mockito.times(1)).getBooks();
    }

    @Test
    void getBookById() {
        BookBean book = new BookBean(1, "Book1", "Pub1", "Aut1");
        Mockito.when(bookClient.getBookById(Mockito.anyInt())).thenReturn(book);
        BookBean bean = bookServiceFeign.getBookById(1);
        assertEquals(book.getAuthor(), bean.getAuthor());
        assertEquals(book.getName(), bean.getName());
        assertEquals(book.getPublisher(), bean.getPublisher());
        Mockito.verify(bookClient, Mockito.times(1)).getBookById(Mockito.anyInt());
    }

    @Test
    void addBook() {
        BookBean book = new BookBean(1, "Book1", "Pub1", "Aut1");
        Mockito.when(bookClient.addBook(Mockito.any())).thenReturn(book);
        BookBean bean = bookServiceFeign.addBook(new BookBean());
        assertEquals(book.getAuthor(), bean.getAuthor());
        assertEquals(book.getName(), bean.getName());
        assertEquals(book.getPublisher(), bean.getPublisher());
        Mockito.verify(bookClient, Mockito.times(1)).addBook(Mockito.any());
    }

    @Test
    void updateBookById() {
        BookBean book = new BookBean(1, "Book1", "Pub1", "Aut1");
        Mockito.when(bookClient.updateBookById(Mockito.anyInt(), Mockito.any())).thenReturn(book);
        BookBean bean = bookServiceFeign.updateBookById(new BookBean(), 1);
        assertEquals(book.getAuthor(), bean.getAuthor());
        assertEquals(book.getName(), bean.getName());
        assertEquals(book.getPublisher(), bean.getPublisher());
        Mockito.verify(bookClient, Mockito.times(1)).updateBookById(Mockito.anyInt(), Mockito.any());
    }

    @Test
    void deleteBookById() {
        BookBean book = new BookBean(1, "Book1", "Pub1", "Aut1");
        Mockito.when(bookClient.deleteBookById(Mockito.anyInt())).thenReturn(book);
        BookBean bean = bookServiceFeign.deleteBookById(1);
        assertEquals(book.getAuthor(), bean.getAuthor());
        assertEquals(book.getName(), bean.getName());
        assertEquals(book.getPublisher(), bean.getPublisher());
        Mockito.verify(bookClient, Mockito.times(1)).deleteBookById(Mockito.anyInt());
    }
}