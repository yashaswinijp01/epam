package com.epam.library.service;

import com.epam.library.bean.BookBean;
import com.epam.library.clients.BookClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookServiceFeignImpl implements BookService{

    @Autowired
    BookClient bookClient;

    @Override
    public List<BookBean> getAllBooksFromLibrary() {
        return bookClient.getBooks();
    }

    @Override
    public BookBean getBookById(int id) {
        return bookClient.getBookById(id);
    }

    @Override
    public BookBean addBook(BookBean bookBean) {
        return bookClient.addBook(bookBean);
    }

    @Override
    public BookBean updateBookById(BookBean bookBean, int id) {
        return bookClient.updateBookById(id, bookBean);
    }

    @Override
    public BookBean deleteBookById(int id) {
        return bookClient.deleteBookById(id);
    }
}
