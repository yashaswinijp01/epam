package com.epam.library.exception;

public class BookAlreadyAllottedException extends RuntimeException{
    public BookAlreadyAllottedException() {}
    public BookAlreadyAllottedException(String message) {
        super(message);
    }
}
