package com.epam.library.bean;

import java.util.List;

public class UsersBookBean {
    private UserBean userBean;
    private List<BookBean> bookBeans;

    public UsersBookBean() {}

    public UsersBookBean(UserBean userBean, List<BookBean> bookBeans) {
        this.userBean = userBean;
        this.bookBeans = bookBeans;
    }

    public UserBean getUserBean() {
        return userBean;
    }

    public void setUserBean(UserBean userBean) {
        this.userBean = userBean;
    }

    public List<BookBean> getBookBeans() {
        return bookBeans;
    }

    public void setBookBeans(List<BookBean> bookBeans) {
        this.bookBeans = bookBeans;
    }

    @Override
    public String toString() {
        return "UsersBookBean{" +
                "userBean=" + userBean +
                ", bookBeans=" + bookBeans +
                '}';
    }
}
