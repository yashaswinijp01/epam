package com.epam.library.service;

import com.epam.library.bean.BookBean;
import com.epam.library.bean.UserBean;
import com.epam.library.bean.UsersBookBean;
import com.epam.library.dao.LibraryDaoWrapper;
import com.epam.library.entity.Library;
import com.epam.library.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    LibraryDaoWrapper libraryDaoWrapper;

    @Autowired
    BookServiceImpl bookService;

    private static final String USER_URI = "http://localhost:9402/";

    @Override
    public List<UserBean> getUsers() {
        ResponseEntity<List<UserBean>> responseEntity =
                restTemplate.exchange(USER_URI + "users", HttpMethod.GET, null, new ParameterizedTypeReference<List<UserBean>>() {});
        return responseEntity.getBody();
    }

    @Override
    public UsersBookBean getUserByUsername(String username) {
        restTemplate.setErrorHandler(new ResponseErrorHandler() {
            @Override
            public boolean hasError(ClientHttpResponse response) throws IOException {
                return response.getStatusCode() == HttpStatus.BAD_REQUEST;
            }

            @Override
            public void handleError(ClientHttpResponse response) throws IOException {
                throw new UserNotFoundException("User not found");
            }
        });
        List<Library> libraryList = libraryDaoWrapper.findByUsername(username);
        List<BookBean> bookBeans = new ArrayList<>();
        UsersBookBean usersBookBean = new UsersBookBean();
        for (Library library: libraryList) {
            BookBean bean = bookService.getBookById(library.getBookId());
            bookBeans.add(bean);
        }
        ResponseEntity<UserBean> responseEntity = restTemplate.exchange(USER_URI + "users/" + username, HttpMethod.GET, null, UserBean.class);
        System.out.println(responseEntity.getBody());
        UserBean bean = responseEntity.getBody();
        usersBookBean.setUserBean(bean);
        usersBookBean.setBookBeans(bookBeans);
        return usersBookBean;
    }

    @Override
    public UserBean addUser(UserBean userBean) {
        HttpEntity<UserBean> httpEntity = new HttpEntity<>(userBean);
        ResponseEntity<UserBean> responseEntity = restTemplate.exchange(USER_URI + "users", HttpMethod.POST, httpEntity, UserBean.class);
        return responseEntity.getBody();
    }

    @Override
    public UserBean deleteUserByUsername(String username) {
        restTemplate.setErrorHandler(new ResponseErrorHandler() {
            @Override
            public boolean hasError(ClientHttpResponse response) throws IOException {
                return response.getStatusCode() == HttpStatus.BAD_REQUEST;
            }

            @Override
            public void handleError(ClientHttpResponse response) throws IOException {
                throw new UserNotFoundException("User not found");
            }
        });
        ResponseEntity<UserBean> responseEntity = restTemplate.exchange(USER_URI + "users/" + username, HttpMethod.DELETE, null, UserBean.class);
        return responseEntity.getBody();
    }

    @Override
    public UserBean updateUserByUsername(UserBean userBean, String username) {
        restTemplate.setErrorHandler(new ResponseErrorHandler() {
            @Override
            public boolean hasError(ClientHttpResponse response) throws IOException {
                return response.getStatusCode() == HttpStatus.BAD_REQUEST;
            }

            @Override
            public void handleError(ClientHttpResponse response) throws IOException {
                throw new UserNotFoundException("User not found");
            }
        });
        HttpEntity<UserBean> httpEntity = new HttpEntity<>(userBean);
        ResponseEntity<UserBean> responseEntity = restTemplate.exchange(USER_URI + "users/" + username, HttpMethod.PUT, httpEntity, UserBean.class);
        return responseEntity.getBody();
    }

    @Override
    public UserBean issueBookToUser(String username, int id) {
        restTemplate.setErrorHandler(new ResponseErrorHandler() {
            @Override
            public boolean hasError(ClientHttpResponse response) throws IOException {
                return response.getStatusCode() == HttpStatus.BAD_REQUEST;
            }

            @Override
            public void handleError(ClientHttpResponse response) throws IOException {
                throw new UserNotFoundException("User not found");
            }
        });
        ResponseEntity<UserBean> responseEntity = restTemplate.exchange(USER_URI + "users/" + username, HttpMethod.GET, null, UserBean.class);
        return responseEntity.getBody();
    }
}
