package com.epam.library.service;

import com.epam.library.bean.BookBean;
import com.epam.library.bean.UserBean;
import com.epam.library.bean.UsersBookBean;
import com.epam.library.clients.UserClient;
import com.epam.library.dao.LibraryDaoWrapper;
import com.epam.library.entity.Library;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceFeignImpl implements UserService{
    @Autowired
    UserClient userClient;

    @Autowired
    LibraryDaoWrapper libraryDaoWrapper;

    @Autowired
    BookServiceFeignImpl bookService;

    @Override
    public List<UserBean> getUsers() {
        return userClient.getAllUsers();
    }

    @Override
    public UsersBookBean getUserByUsername(String username) {
        List<Library> libraryList = libraryDaoWrapper.findByUsername(username);
        List<BookBean> bookBeans = new ArrayList<>();
        UsersBookBean usersBookBean = new UsersBookBean();
        for (Library library: libraryList) {
            BookBean bean = bookService.getBookById(library.getBookId());
            bookBeans.add(bean);
        }
        UserBean bean = userClient.getUserByUsername(username);
        usersBookBean.setUserBean(bean);
        usersBookBean.setBookBeans(bookBeans);
        return usersBookBean;
    }

    @Override
    public UserBean addUser(UserBean userBean) {
        return userClient.addUser(userBean);
    }

    @Override
    public UserBean deleteUserByUsername(String username) {
        return userClient.deleteUser(username);
    }

    @Override
    public UserBean updateUserByUsername(UserBean userBean, String username) {
        return userClient.updateUser(username, userBean);
    }

    @Override
    public UserBean issueBookToUser(String username, int id) {
        return userClient.getUserByUsername(username);
    }
}
