package com.epam.library.exception;

import feign.FeignException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class ErrorHandler {

    @ExceptionHandler(FeignException.class)
    public ResponseEntity<Map<String, String>> feignExceptions(FeignException e){
        Map<String, String> response = new HashMap<>();
        response.put("service", "feign");
        response.put("timeStamp", new Date().toString());
        response.put("error", e.getMessage());
        response.put("status", String.valueOf(e.status()));
        return new ResponseEntity<>(response, HttpStatus.valueOf(e.status()));
    }

    @ExceptionHandler(BookAlreadyAllottedException.class)
    public ResponseEntity<Map<String, String>> bookAlreadyAllotted(BookAlreadyAllottedException e){
        Map<String, String> response = new HashMap<>();
        response.put("service", "books");
        response.put("timeStamp", new Date().toString());
        response.put("error", e.getMessage());
        response.put("status", String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(MaximumBookAllottedToUserException.class)
    public ResponseEntity<Map<String, String>> BookNotFound(MaximumBookAllottedToUserException e){
        Map<String, String> response = new HashMap<>();
        response.put("service", "books");
        response.put("timeStamp", new Date().toString());
        response.put("error", e.getMessage());
        response.put("status", String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
