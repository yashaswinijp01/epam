package com.epam.library.dao;

import com.epam.library.entity.Library;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LibraryDao extends JpaRepository<Library, Integer> {
    Library findByUsernameAndBookId(String username, int bookId);
    void deleteByUsernameAndBookId(String username, int bookId);
    List<Library> findByUsername(String username);
    int countByUsername(String username);
}
