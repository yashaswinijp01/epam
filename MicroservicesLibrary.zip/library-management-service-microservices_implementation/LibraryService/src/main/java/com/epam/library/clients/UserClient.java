package com.epam.library.clients;

import com.epam.library.bean.UserBean;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "user")
@LoadBalancerClient(name = "user")
public interface UserClient {
    @GetMapping("/users")
    List<UserBean> getAllUsers();

    @GetMapping("/users/{username}")
    UserBean getUserByUsername(@PathVariable("username") String username);

    @PostMapping("/users")
    UserBean addUser(@RequestBody UserBean userBean);

    @DeleteMapping("/users/{username}")
    UserBean deleteUser(@PathVariable("username") String username);

    @PutMapping("/users/{username}")
    UserBean updateUser(@PathVariable("username") String username, @RequestBody UserBean userBean);
}
