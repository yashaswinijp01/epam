package com.epam.library.service;

import com.epam.library.dao.LibraryDao;
import com.epam.library.dao.LibraryDaoWrapper;
import com.epam.library.entity.Library;
import com.epam.library.exception.BookAlreadyAllottedException;
import com.epam.library.exception.MaximumBookAllottedToUserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LibraryServiceImpl implements LibraryService{
    @Autowired
    LibraryDaoWrapper libraryDaoWrapper;

    @Autowired
    LibraryDao libraryDao;

    @Override
    public Library save(Library library) {
        int count = libraryDao.countByUsername(library.getUsername());
        Library userBook = libraryDao.findByUsernameAndBookId(library.getUsername(), library.getBookId());
        if (userBook != null)
            throw new BookAlreadyAllottedException("Book already allotted to user");
        if (count >= 3)
            throw new MaximumBookAllottedToUserException("Book slots filled for user");
        return libraryDaoWrapper.save(library);
    }

    @Override
    public Library deleteByUsernameAndBookId(String username, int id) {
        return libraryDaoWrapper.deleteByUsernameAndBookId(username, id);
    }
}
