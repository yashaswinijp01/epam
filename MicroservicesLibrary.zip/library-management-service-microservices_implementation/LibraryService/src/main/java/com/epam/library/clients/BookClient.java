package com.epam.library.clients;

import com.epam.library.bean.BookBean;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "book")
@LoadBalancerClient(name = "book")
public interface BookClient {

    @GetMapping("/books")
    List<BookBean> getBooks();

    @GetMapping("/books/{id}")
    BookBean getBookById(@PathVariable("id") int id);

    @PostMapping("/books")
    BookBean addBook(@RequestBody BookBean bookBean);

    @PutMapping("/books/{id}")
    BookBean updateBookById(@PathVariable("id") int id, @RequestBody BookBean bookBean);

    @DeleteMapping("/books/{id}")
    BookBean deleteBookById(@PathVariable("id") int id);
}
