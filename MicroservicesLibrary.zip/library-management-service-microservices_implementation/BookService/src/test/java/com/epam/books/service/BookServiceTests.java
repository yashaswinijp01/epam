package com.epam.books.service;

import com.epam.books.bean.BookBean;
import com.epam.books.dao.BookDaoWrapper;
import com.epam.books.entity.Book;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class BookServiceTests {

    @InjectMocks
    BookServiceImpl bookService;

    @Mock
    BookDaoWrapper bookDaoWrapper;

    @Test
    void getAllBooks() {
        Book book1 = new Book(1, "Book1", "Pub1", "Aut1");
        Book book2 = new Book(2, "Book2", "Pub2", "Aut2");
        Book book3 = new Book(3, "Book3", "Pub3", "Aut3");
        List<Book> books = Arrays.asList(book1, book2, book3);

        Mockito.when(bookDaoWrapper.findAll()).thenReturn(books);

        //Test
        List<Book> result = bookService.findAll();

        Assertions.assertEquals(3, result.size());
        Mockito.verify(bookDaoWrapper, Mockito.times(1)).findAll();
    }

    @Test
    void getBookById() {
        Book book = new Book(1, "Book", "Pub", "Aut");
        Mockito.when(bookDaoWrapper.findById(Mockito.anyInt())).thenReturn(book);

        Book newBook = bookService.findById(1);

        Assertions.assertEquals("Book", newBook.getName());
        Assertions.assertEquals("Pub", newBook.getPublisher());
        Assertions.assertEquals("Aut", newBook.getAuthor());
    }

    @Test
    void getBookByIdWhenIdNotAvailable() {
        Mockito.when(bookDaoWrapper.findById(Mockito.anyInt())).thenReturn(null);

        Book newBook = bookService.findById(1);

        Assertions.assertNull(newBook);
    }

    @Test
    void addBook() {
        Book book = new Book(1, "Book", "Pub", "Aut");
        Mockito.when(bookDaoWrapper.save(Mockito.any())).thenReturn(book);

        Book savedBook = bookService.save(new BookBean());

        Assertions.assertEquals("Book", savedBook.getName());
        Assertions.assertEquals("Pub", savedBook.getPublisher());
        Assertions.assertEquals("Aut", savedBook.getAuthor());
    }

    @Test
    void deleteBook() {
        Book book = new Book(1, "Book", "Pub", "Aut");
        Mockito.when(bookDaoWrapper.deleteById(Mockito.anyInt())).thenReturn(book);

        Book deletedBook = bookService.deleteById(1);

        Assertions.assertEquals("Book", deletedBook.getName());
        Assertions.assertEquals("Pub", deletedBook.getPublisher());
        Assertions.assertEquals("Aut", deletedBook.getAuthor());
    }

    @Test
    void deleteBookWhenIdNotAvailable() {
        Mockito.when(bookDaoWrapper.deleteById(Mockito.anyInt())).thenReturn(null);

        Book deletedBook = bookService.deleteById(1);

        Assertions.assertNull(deletedBook);
    }

    @Test
    void updateBookById() {
        Book book = new Book(1, "Book", "Pub", "Aut");
        Mockito.when(bookDaoWrapper.updateById(Mockito.anyInt(), Mockito.any())).thenReturn(book);

        Book updatedBook = bookService.updateBook(1, new BookBean());

        Assertions.assertEquals("Book", updatedBook.getName());
        Assertions.assertEquals("Pub", updatedBook.getPublisher());
        Assertions.assertEquals("Aut", updatedBook.getAuthor());
    }

    @Test
    void updateBookWhenIdNotAvailable() {
        Mockito.when(bookDaoWrapper.updateById(Mockito.anyInt(), Mockito.any())).thenReturn(null);

        Book updatedBook = bookService.updateBook(1, new BookBean());

        Assertions.assertNull(updatedBook);
    }
}
