package com.epam.books.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class ErrorHandler {
    @ExceptionHandler(BookNotFoundException.class)
    public ResponseEntity<Map<String, String>> bookAlreadyAllotted(BookNotFoundException e){
        Map<String, String> response = new HashMap<>();
        response.put("service", "books");
        response.put("timeStamp", new Date().toString());
        response.put("error", e.getMessage());
        response.put("status", String.valueOf(HttpStatus.BAD_REQUEST.value()));
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
}
