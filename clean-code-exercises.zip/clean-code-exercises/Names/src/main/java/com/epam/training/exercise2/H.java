package com.epam.training.exercise2;

public class H {

	// print some Harshad numbers
	public static void main(String[] args) {
		long L = 1000; // limit the seq of Harshad numbers
		int N, S;
		for (int i = 1; i <= L; i++) {
			N = i;
			S = 0;
			while (N != 0) {
				S += N % 10;
				N = N / 10;
			}
			if (i % S == 0) {
				System.out.println(i);
			}
		}
	}

}
