package com.epam.training.exercise2;

/**
 * Excerpt from sun.misc.FloatingDecimal jdk 1.6u23
 */
public class FloatingDecimal {

	// highbytes
	static final long h = 0xff00000000000000L;
	
	// lowbytes
	static final long l = ~h;

	/*
	 * count number of bits from high-order 1 bit to low-order 1 bit, inclusive.
	 */
	public static int countBits(long v) {
		//
		// the strategy is to shift until we get a non-zero sign bit
		// then shift until we have no bits left, counting the difference.
		// we do byte shifting as a hack. Hope it helps.
		//
		if (v == 0L)
			return 0;

		while ((v & h) == 0L) {
			v <<= 8;
		}
		while (v > 0L) { // i.e. while ((v&highbit) == 0L )
			v <<= 1;
		}

		int n = 0;
		while ((v & l) != 0L) {
			v <<= 8;
			n += 8;
		}
		while (v != 0L) {
			v <<= 1;
			n += 1;
		}
		return n;
	}

}
