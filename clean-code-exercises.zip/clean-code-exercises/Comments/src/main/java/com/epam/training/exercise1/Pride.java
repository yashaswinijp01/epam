package com.epam.training.exercise1;

/**
 * @author Clean Coder
 *
 *         Dear Fellow Clean Coder!
 *
 *         Let me explain my intentions, please don't delete this comment. This
 *         is my legacy!
 *
 *         I was the most expert programmer in the world, and yet when my wife
 *         discovered the malignant stage 4 paraganglioma, all that perl and C++
 *         and knowledge of forked looped chain arrays could do nothing.
 * 
 *         So I packed up my seven laptops and my eight monitors and unrolled a
 *         spool of CAT6 cable into the cellar. I disappeared from the world
 *         while my wife remained in it. While she went about reassigning her
 *         cases at the nonprofit, I tasked my IRC client to chat with fifteen
 *         of the greatest geniuses in other fields. She went to the drugstore
 *         and the ice cream store and the drugstore again, and called someone
 *         to cut the grass that usually I cut. And at night she finished her
 *         library books, one by one so I would not have to remember to return
 *         them, while the other side of the bed remained flat.
 * 
 *         On the seventh day, I arose from the cellar, eyes caffeinated and
 *         bloodshot. I seized her arm, muttering about a new operating system,
 *         a new programming language. GACT, I called it, and said it was a
 *         recursive acronym for GACT Altered Code Translation, and laughed
 *         wildly. She text messaged work, and she followed me to Sweden, where
 *         one of the other geniuses lived.
 * 
 *         That's it, have a nice day!
 *
 */
public class Pride {

	/**
	 * Method isPrime
	 * 
	 * @param n Parameter n
	 * @return The return value
	 */
	public static boolean isPrime(final int n) {
		boolean r = true;									// store result here, defaults to true
		
		for (int i = 2; i <= Math.sqrt(n) && r; ++i) {		// we don't need to check divisors below 2
															// don't use i++, because it's slower (and I hate it)
				
			if (n % i == 0) {								// if parameter is divisible with the divisor				
				r = false;									// it is not a prime
															// Please don't use break / return here. I like my code to be clean.
			}
		}
		return r;											// Return the result
	}
	
}
