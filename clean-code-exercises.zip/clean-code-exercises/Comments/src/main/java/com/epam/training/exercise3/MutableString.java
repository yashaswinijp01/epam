package com.epam.training.exercise3;

import java.io.Serializable;
import java.util.Arrays;

/**
 * Based on java.lang.String
 */
public class MutableString implements Serializable {

	/** The value is used for character storage. */
	private char value[];

	/** Cache the hash code for the string */
	private int hash; // Default to 0

	/** use serialVersionUID from JDK 1.0.2 for interoperability */
	private static final long serialVersionUID = -6849794470754667710L;

	/**
	 * Initializes a newly created {@code MutableString} object so that it
	 * represents an empty character sequence.
	 */
	public MutableString() {
		this.value = new char[0];
	}

	/**
	 * Initializes a newly created {@code String} object so that it represents
	 * the same sequence of characters as the argument; in other words, the
	 * newly created string is a copy of the argument string.
	 *
	 * @param original
	 *            A {@code String}
	 */
	public MutableString(MutableString original) {
		this.value = original.value;
		this.hash = original.hash;
	}

	/**
	 * Allocates a new {@code String} so that it represents the sequence of
	 * characters currently contained in the character array argument. The
	 * contents of the character array are copied; subsequent modification of
	 * the character array does not affect the newly created string.
	 *
	 * @param value
	 *            The initial value of the string
	 */
	public MutableString(char value[]) {
		this.value = Arrays.copyOf(value, value.length);
	}

	/**
	 * @return the value
	 */
	public char[] getValue() {
		return Arrays.copyOf(value, value.length);
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(char[] value) {
		this.value = value;
		this.hash = 0;
	}

	/**
	 * Returns a hash code for this string. The hash code for a {@code String}
	 * object is computed as <blockquote>
	 * 
	 * <pre>
	 * s[0]*31^(n-1) + s[1]*31^(n-2) + ... + s[n-1]
	 * </pre>
	 * 
	 * </blockquote> using {@code int} arithmetic, where {@code s[i]} is the
	 * <i>i</i>th character of the string, {@code n} is the length of the
	 * string, and {@code ^} indicates exponentiation. (The hash value of the
	 * empty string is zero.)
	 *
	 * @return a hash code value for this object.
	 */
	public int hashCode() {
		int h = hash;
		if (h == 0 && value.length > 0) {
			char val[] = value;

			for (int i = 0; i < value.length; i++) {
				h = 31 * h + val[i];
			}
			hash = h;
		}
		return h;
	}

	public int indexOf(int ch, int fromIndex) {
		final int max = value.length;
		if (fromIndex < 0) {
			fromIndex = 0;
		} else if (fromIndex >= max) {
			// Note: fromIndex might be near -1>>>1.
			return -1;
		}

		if (ch < Character.MIN_SUPPLEMENTARY_CODE_POINT) {
			// handle most cases here (ch is a BMP code point or a
			// negative value (invalid code point))
			final char[] value = this.value;
			for (int i = fromIndex; i < max; i++) {
				if (value[i] == ch) {
					return i;
				}
			}
			return -1;
		} else {
			return indexOfSupplementary(ch, fromIndex);
		}
	}

	/**
	 * Handles (rare) calls of indexOf with a supplementary character.
	 */
	private int indexOfSupplementary(int ch, int fromIndex) {
		if (Character.isValidCodePoint(ch)) {
			final char[] value = this.value;
			final char hi = Character.highSurrogate(ch);
			final char lo = Character.lowSurrogate(ch);
			final int max = value.length - 1;
			for (int i = fromIndex; i < max; i++) {
				if (value[i] == hi && value[i + 1] == lo) {
					return i;
				}
			}
		}
		return -1;
	}

}
