package model;

public class SnakeDeadException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
