package model;

public interface Member {

	boolean occupies(Coordinate coordinate);
	
}
