# Using the AWS SDK for Python \(Boto\)<a name="UsingTheBotoAPI"></a>

Boto is a Python package that provides interfaces to AWS including Amazon S3\. For more information about Boto, go to the [AWS SDK for Python \(Boto\)](https://aws.amazon.com/sdk-for-python/)\. The getting started link on this page provides step\-by\-step instructions to get started\. 