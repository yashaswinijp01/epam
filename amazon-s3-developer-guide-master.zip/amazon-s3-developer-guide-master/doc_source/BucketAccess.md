# Buckets and access control<a name="BucketAccess"></a>

Each bucket has an associated access control policy\. This policy governs the creation, deletion and enumeration of objects within the bucket\. For more information, see [Identity and access management in Amazon S3](s3-access-control.md)\. 