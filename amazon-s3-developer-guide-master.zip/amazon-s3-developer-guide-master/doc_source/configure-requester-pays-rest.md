# Configure Requester Pays with the REST API<a name="configure-requester-pays-rest"></a>

**Topics**
+ [Setting the requestPayment Bucket Configuration](RequesterPaysBucketConfiguration.md)
+ [Retrieving the requestPayment Configuration](BucketPayerValues.md)
+ [Downloading objects in Requester Pays buckets](ObjectsinRequesterPaysBuckets.md)