# Restore an archived object using the REST API<a name="restoring-objects-rest"></a>

Amazon S3 provides an API for you to initiate an archive restoration\. For more information, see [POST Object restore](https://docs.aws.amazon.com/AmazonS3/latest/API/RESTObjectPOSTrestore.html) in the *Amazon Simple Storage Service API Reference*\.