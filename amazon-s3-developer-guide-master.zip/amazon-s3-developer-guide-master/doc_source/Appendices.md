# Appendices<a name="Appendices"></a>

This Amazon Simple Storage Service Developer Guide appendix include the following sections\.

**Topics**
+ [Appendix a: Using the SOAP API](SOAPAPI3.md)
+ [Appendix b: Authenticating requests \(AWS signature version 2\)](auth-request-sig-v2.md)