# Deleting an object using the REST API<a name="DeletingAnObjectsUsingREST"></a>

You can use the AWS SDKs to delete an object\. However, if your application requires it, you can send REST requests directly\. For more information, go to [DELETE Object](https://docs.aws.amazon.com/AmazonS3/latest/API/RESTObjectDELETE.html) in the *Amazon Simple Storage Service API Reference*\. 