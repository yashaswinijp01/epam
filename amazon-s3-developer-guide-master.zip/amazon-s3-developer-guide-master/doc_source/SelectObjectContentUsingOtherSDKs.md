# Selecting content from objects using other SDKs<a name="SelectObjectContentUsingOtherSDKs"></a>

You can select the contents of an object using Amazon S3 Select using other SDKs\. For more information, see the following:
+ Python: [Using the AWS SDK for Python \(Boto\)](UsingTheBotoAPI.md)\.
+ Ruby: [Using the AWS SDK for Ruby \- Version 3](UsingTheMPRubyAPI.md)\.