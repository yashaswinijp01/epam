# Upload an object using the REST API<a name="UploadObjSingleOpREST"></a>

You can use AWS SDK to upload an object\. However, if your application requires it, you can send REST requests directly\. You can send a PUT request to upload data in a single operation\. For more information, see [PUT Object](https://docs.aws.amazon.com/AmazonS3/latest/API/RESTObjectPUT.html)\.