## This guide has been archived
This guide has been archived. Please see https://github.com/awsdocs/amazon-s3-userguide which combines information from the three retired Amazon S3 guides: Amazon S3 Developer Guide, Console User Guide, and Getting Started Guide. 

## Amazon S3 Devloper Guide

The open source version of the Amazon S3 Devloper Guide. You can submit feedback & requests for changes by submitting issues in this repo or by making proposed changes & submitting a pull request.

## License Summary

The documentation is made available under the Creative Commons Attribution-ShareAlike 4.0 International License. See the LICENSE file.

The sample code within this documentation is made available under a modified MIT license. See the LICENSE-SAMPLECODE file.
